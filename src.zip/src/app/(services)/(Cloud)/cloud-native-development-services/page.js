import CloudNative from '@/pages/CloudNative';

export default function CloudNativePage() {
  return (
    <main>
      <CloudNative />
    </main>
  );
}