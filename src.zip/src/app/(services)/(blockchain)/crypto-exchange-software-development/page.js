import ExchangeShoftware from '@/pages/ExchangeShoftware';

export default function ExchangeShoftwarePage() {
  return (
    <main>
      <ExchangeShoftware />
    </main>
  );
}