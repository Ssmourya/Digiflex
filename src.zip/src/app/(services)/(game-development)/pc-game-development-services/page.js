import PCGameDevelopment from '@/pages/PCGameDevelopment';

export default function PCGameDevelopmentPage() {
  return (
    <main>
      <PCGameDevelopment />
    </main>
  );
}