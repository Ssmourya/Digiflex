import SmartContractDevelopment from '@/pages/SmartContractDevelopment';

export default function SmartContractDevelopmentPage() {
  return (
    <main>
      <SmartContractDevelopment />
    </main>
  );
}