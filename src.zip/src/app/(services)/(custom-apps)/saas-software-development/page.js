import SAASDEVELOPMENT from '@/pages/SAASDEVELOPMENT';

export default function SAASDEVELOPMENTPage() {
  return (
    <main>
      <SAASDEVELOPMENT />
    </main>
  );
}