import PythonDevelopment from '@/pages/PythonDevelopment';

export default function PythonDevelopmentPage() {
  return (
    <main>
      <PythonDevelopment />
    </main>
  );
}