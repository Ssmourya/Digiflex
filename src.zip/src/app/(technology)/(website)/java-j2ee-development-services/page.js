import Java from '@/pages/JavaDevelopemt';

export default function JavaPage() {
  return (
    <main>
      <Java />
    </main>
  );
}