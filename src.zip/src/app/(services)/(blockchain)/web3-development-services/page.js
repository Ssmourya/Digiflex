import Web3 from '@/pages/Web3';

export default function Web3Page() {
  return (
    <main>
      <Web3 />
    </main>
  );
}