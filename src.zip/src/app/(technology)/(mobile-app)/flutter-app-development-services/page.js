import FlutterAppDevlopment from '@/pages/FlutterAppDevlopment';

export default function FlutterAppDevlopmentPage() {
  return (
    <main>
      <FlutterAppDevlopment />
    </main>
  );
}