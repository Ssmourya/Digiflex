import VueDevelopment from '@/pages/VueDevelopment';

export default function VueDevelopmentPage() {
  return (
    <main>
      <VueDevelopment />
    </main>
  );
}
