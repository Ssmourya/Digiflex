import Magento from '@/pages/MagentoDevelopment';

export default function MagentoPage() {
  return (
    <main>
      <Magento />
    </main>
  );
}