import CloudOptimization from '@/pages/CloudOptimization';

export default function CloudOptimizationPage() {
  return (
    <main>
      <CloudOptimization />
    </main>
  );
}