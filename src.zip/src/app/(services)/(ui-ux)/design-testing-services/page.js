import DesignTesting from '@/pages/DesignTesting';

export default function DesignTestingPage() {
  return (
    <main>
      <DesignTesting />
    </main>
  );
}