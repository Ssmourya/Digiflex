import Ai_development from '@/pages/Ai_development';

export default function Ai_developmentPage() {
  return (
    <main>
      <Ai_development />
    </main>
  );
}