import BlockChainDevlopment from '@/pages/BlockChainDevlopment';

export default function BlockchainDevelopmentPage() {
  return (
    <main>
      <BlockChainDevlopment />
    </main>
  );
}
