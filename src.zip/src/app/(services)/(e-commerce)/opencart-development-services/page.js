import Opencart from '@/pages/OpencartDevelopment';

export default function OpencartPage() {
  return (
    <main>
      <Opencart />
    </main>
  );
}