import SecurityTesting from '@/pages/SecurityTesting';

export default function SecurityTestingPage() {
  return (
    <main>
      <SecurityTesting />
    </main>
  );
}