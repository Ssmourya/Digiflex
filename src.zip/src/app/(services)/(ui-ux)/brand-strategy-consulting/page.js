import BrandStrategy from '@/pages/BrandStrategy';

export default function BrandStrategyPage() {
  return (
    <main>
      <BrandStrategy />
    </main>
  );
}