import Llm_development from '@/pages/Llm_development';

export default function Llm_developmentPage() {
  return (
    <main>
      <Llm_development />
    </main>
  );
}