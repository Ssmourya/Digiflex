import ReactNative from '@/pages/ReactNative';

export default function ReactNativePage() {
  return (
    <main>
      <ReactNative />
    </main>
  );
}