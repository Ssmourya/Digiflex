import ReactDevelopment from '@/pages/ReactDevelopment';

export default function ReactDevelopmentPage() {
  return (
    <main>
      <ReactDevelopment />
    </main>
  );
}
