import NativeScript from '@/pages/NativeScript';

export default function NativeScriptPage() {
  return (
    <main>
      <NativeScript />
    </main>
  );
}