import CryptocurrencyWallet from '@/pages/CryptocurrencyWallet';

export default function CryptocurrencyWalletPage() {
  return (
    <main>
      <CryptocurrencyWallet />
    </main>
  );
}