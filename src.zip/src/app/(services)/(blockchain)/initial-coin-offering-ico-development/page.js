import InitialCoinOffering from '@/pages/InitialCoinOffering';

export default function InitialCoinOfferingPage() {
  return (
    <main>
      <InitialCoinOffering />
    </main>
  );
}