import Cloud_Migration from '@/pages/Cloud_Migration';

export default function Cloud_MigrationPage() {
  return (
    <main>
      <Cloud_Migration />
    </main>
  );
}