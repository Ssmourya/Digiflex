import WebConsulting from '@/pages/WebConsulting';

export default function WebConsultingPage() {
  return (
    <main>
      <WebConsulting />
    </main>
  );
}