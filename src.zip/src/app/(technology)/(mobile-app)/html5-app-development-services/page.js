import HtmlDevlopment from '@/pages/HtmlAppDevlopment';

export default function HtmlDevlopmentPage() {
  return (
    <main>
      <HtmlDevlopment />
    </main>
  );
}