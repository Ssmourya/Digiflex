import Intercloud_Migration from '@/pages/Intercloud';

export default function Intercloud_MigrationPage() {
  return (
    <main>
      <Intercloud_Migration />
    </main>
  );
}