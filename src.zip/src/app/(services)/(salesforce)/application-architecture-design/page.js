import ApplicationArchitecture from '@/pages/ApplicationArchitecture';

export default function ApplicationArchitecturePage() {
  return (
    <main>
      <ApplicationArchitecture />
    </main>
  );
}