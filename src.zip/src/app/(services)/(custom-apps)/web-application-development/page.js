import WebApplicationDevlopment from '@/pages/WebApplicationDevlopment';

export default function WebApplicationDevelopmentPage() {
  return (
    <main>
      <WebApplicationDevlopment />
    </main>
  );
}
