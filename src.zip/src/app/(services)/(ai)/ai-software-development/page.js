import Ai_software from '@/pages/Ai_software';

export default function Ai_softwarePage() {
  return (
    <main>
      <Ai_software />
    </main>
  );
}