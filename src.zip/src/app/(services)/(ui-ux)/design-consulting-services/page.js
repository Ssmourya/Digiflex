import DesignConsulting from '@/pages/DesignConsulting';

export default function DesignConsultingPage() {
  return (
    <main>
      <DesignConsulting />
    </main>
  );
}