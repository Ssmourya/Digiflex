import WebsiteDevlopment from '@/pages/WebsiteDevlopment';

export default function WebsiteDevlopmentPage() {
  return (
    <main>
      <WebsiteDevlopment />
    </main>
  );
}