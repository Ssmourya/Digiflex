import AiConsulting from '@/pages/AiConsulting';

export default function AiConsultingPage() {
  return (
    <main>
      <AiConsulting />
    </main>
  );
}