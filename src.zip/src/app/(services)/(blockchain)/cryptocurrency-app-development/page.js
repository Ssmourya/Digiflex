import CryptocurrencyApp from '@/pages/CryptocurrencyApp';

export default function CryptocurrencyAppPage() {
  return (
    <main>
      <CryptocurrencyApp />
    </main>
  );
}