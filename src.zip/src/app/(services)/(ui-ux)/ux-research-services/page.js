import UxResearch from '@/pages/UxResearch';

export default function UxResearchPage() {
  return (
    <main>
      <UxResearch />
    </main>
  );
}