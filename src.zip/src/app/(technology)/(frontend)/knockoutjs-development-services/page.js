import KnowkoutjsDevelopment from '@/pages/KnowkoutjsDevelopment';

export default function KnowkoutjsDevelopmentPage() {
  return (
    <main>
      <KnowkoutjsDevelopment />
    </main>
  );
}