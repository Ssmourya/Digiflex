import Unity3dGameDevelopment from '@/pages/Unity3dGameDevelopment';

export default function Unity3dGameDevelopmentPage() {
  return (
    <main>
      <Unity3dGameDevelopment />
    </main>
  );
}