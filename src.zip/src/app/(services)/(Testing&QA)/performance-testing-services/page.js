import PerformanceTesting from '@/pages/PerformanceTesting';

export default function PerformanceTestingPage() {
  return (
    <>
      <PerformanceTesting />
    </>
  );
}
