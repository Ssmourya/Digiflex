import Ai_chatbot from '@/pages/Ai_chatbot';

export default function Ai_chatbotPage() {
  return (
    <main>
      <Ai_chatbot />
    </main>
  );
}