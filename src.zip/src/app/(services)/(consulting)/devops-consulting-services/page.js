import AiConsulting from '@/pages/DevopsConsulting';

export default function DevopsConsultingPage() {
  return (
    <main>
      <AiConsulting />
    </main>
  );
}