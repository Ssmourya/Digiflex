import Odoo from '@/pages/OdooDevelopment';

export default function OdooPage() {
  return (
    <main>
      <Odoo />
    </main>
  );
}