import SeleniumAutomationTesting from '@/pages/SeleniumAutomationTesting';

export default function SeleniumAutomationTestingPage() {
  return (
    <main>
      <SeleniumAutomationTesting />
    </main>
  );
}