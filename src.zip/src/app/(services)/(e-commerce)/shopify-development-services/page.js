import Shopify from '@/pages/Shopifydevlopment';

export default function ShopifyPage() {
  return (
    <main>
      <Shopify />
    </main>
  );
}