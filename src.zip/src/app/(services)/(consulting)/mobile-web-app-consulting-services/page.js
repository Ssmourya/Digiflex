
import MobileConsulting from '@/pages/MobileConsulting';

export default function MobileConsultingPage() {
  return (
    <main>
      <MobileConsulting />
    </main>
  );
}