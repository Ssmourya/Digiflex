import UnrealGameDevelopment from '@/pages/UnrealGameDevelopment';

export default function UnrealGameDevelopmentPage() {
  return (
    <main>
      <UnrealGameDevelopment />
    </main>
  );
}