import TestingConsulting from '@/pages/TestingConsulting';

export default function TestingConsultingPage() {
  return (
    <main>
      <TestingConsulting />
    </main>
  );
}