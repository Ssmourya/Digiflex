import ConsultingAssesment from '@/pages/ConsultingAssesment';

export default function ConsultingAssesmentPage() {
  return (
    <main>
      <ConsultingAssesment />
    </main>
  );
}