import Pestrashop from '@/pages/PestrashopDevelopment';

export default function PestrashopPage() {
  return (
    <main>
      <Pestrashop />
    </main>
  );
}