import DefiDevelopment from '@/pages/DefiDevelopment';

export default function DefiDevelopmentPage() {
  return (
    <main>
      <DefiDevelopment />
    </main>
  );
}