import SoftwareTestManagement from '@/pages/SoftwareTestManagement';

export default function SoftwareTestManagementPage() {
  return (
    <main>
      <SoftwareTestManagement />
    </main>
  );
}
