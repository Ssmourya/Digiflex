import WebsiteTechDevlopmet from '@/pages/Mern';

export default function WebsiteTechDevlopmetPage() {
  return (
    <main>
      <WebsiteTechDevlopmet />
    </main>
  );
}