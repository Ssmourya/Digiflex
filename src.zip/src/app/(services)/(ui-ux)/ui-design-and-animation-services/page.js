import UiAnimation from '@/pages/UiAnimation';

export default function UiAnimationPage() {
  return (
    <main>
      <UiAnimation />
    </main>
  );
}