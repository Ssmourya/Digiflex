import NftMarketplace from '@/pages/NftMarketplace';

export default function NftMarketplacePage() {
  return (
    <main>
      <NftMarketplace/>
    </main>
  );
}