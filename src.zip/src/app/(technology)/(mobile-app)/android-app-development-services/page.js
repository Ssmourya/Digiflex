import AndroidAppDevlopment from '@/pages/AndroidAppDevlopment';

export default function AndroidAppDevlopmentPage() {
  return (
    <main>
      <AndroidAppDevlopment />
    </main>
  );
}