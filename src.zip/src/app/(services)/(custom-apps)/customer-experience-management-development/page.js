import CEMDEVELOPMENT from '@/pages/CEMDEVELOPMENT';

export default function CEMDEVELOPMENTPage() {
  return (
    <main>
      <CEMDEVELOPMENT />
    </main>
  );
}