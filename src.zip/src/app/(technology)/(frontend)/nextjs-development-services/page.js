import NextjsDevelopment from '@/pages/NextjsDevelopment';

export default function NextjsDevelopmentPage() {
  return (
    <main>
      <NextjsDevelopment />
    </main>
  );
}