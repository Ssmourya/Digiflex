import ResourceAugmentation from '@/pages/ResourceAugmentation';

export default function ResourceAugmentationPage() {
  return (
    <main>
      <ResourceAugmentation />
    </main>
  );
}