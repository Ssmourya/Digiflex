import Google from '@/pages/Google';

export default function GooglePage() {
  return (
    <main>
      <Google />
    </main>
  );
}