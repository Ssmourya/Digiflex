import IntregrationandMigration from '@/pages/IntregrationandMigration';

export default function IntregrationandMigrationPage() {
  return (
    <main>
      <IntregrationandMigration />
    </main>
  );
}