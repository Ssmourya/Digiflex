import AWS from '@/pages/AWS';

export default function AWSPage() {
  return (
    <main>
      <AWS />
    </main>
  );
}