import XamarinAppDEvlopment from '@/pages/XamarinAppDevelopment';

export default function XamarinAppDEvlopmentPage() {
  return (
    <main>
      <XamarinAppDEvlopment />
    </main>
  );
}