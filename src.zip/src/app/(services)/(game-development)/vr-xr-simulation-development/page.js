import VR_XRSimulation from '@/pages/VR_XRSimulation';

export default function VR_XRSimulationPage() {
  return (
    <main>
      <VR_XRSimulation />
    </main>
  );
}