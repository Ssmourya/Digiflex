import IosDevelopmentTech from '@/pages/IosDevelopmentTech';

export default function IosDevelopmentTechPage() {
  return (
    <main>
      <IosDevelopmentTech />
    </main>
  );
}