import MobileAppDevlopment from '@/pages/MobileAppDevlopment';

export default function MobileAppDevelopmentPage() {
  return (
    <main>
      <MobileAppDevlopment />
    </main>
  );
}
