import AngularDevelopment from '@/pages/AngularDevelopment';

export default function AngularDevelopmentPage() {
  return (
    <main>
      <AngularDevelopment />
    </main>
  );
}
