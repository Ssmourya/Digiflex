import ContactPage from '@/pages/ContactPage';

export default function Contact() {
  return (
    <main>
      <ContactPage />
    </main>
  );
}
