import ProductDesign from '@/pages/ProductDesign';

export default function ProductDesignPage() {
  return (
    <main>
      <ProductDesign />
    </main>
  );
}