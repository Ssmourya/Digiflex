import SalesforceConsulting from '@/pages/SalesforceConsulting';

export default function SalesforceConsultingPage() {
  return (
    <main>
      <SalesforceConsulting />
    </main>
  );
}