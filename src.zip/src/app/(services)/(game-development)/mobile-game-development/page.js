import MobileGameDevelopment from '@/pages/MobileGameDevelopment';

export default function MobileGameDevelopmentPage() {
  return (
    <main>
      <MobileGameDevelopment />
    </main>
  );
}