import React from 'react'
import Belive from './Belive'
import OurValues from './OurValues'
import DefineUs from './DefineUs'
import StatItem from './StatItems'
// import OurJourney from './OurJourneys'

function Body() {
  return (
    <div>
      <Belive/>
      <StatItem/>
      <OurValues/>
      <DefineUs/>
      {/* <OurJourney/> */}


      
    </div>
  )
}

export default Body
