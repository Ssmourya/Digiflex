import Azure from '@/pages/Azure';

export default function AzurePage() {
  return (
    <main>
      <Azure />
    </main>
  );
}