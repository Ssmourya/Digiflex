import Woo from '@/pages/WooDevelopment';

export default function WooPage() {
  return (
    <main>
      <Woo />
    </main>
  );
}