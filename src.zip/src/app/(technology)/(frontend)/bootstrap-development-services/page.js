import BootstrapDevelopment from '@/pages/BootstrapDevelopment';

export default function BootstrapDevelopmentPage() {
  return (
    <main>
      <BootstrapDevelopment />
    </main>
  );
}