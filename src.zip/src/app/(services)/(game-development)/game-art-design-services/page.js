import GameArtServices from '@/pages/GameArtServices';

export default function GameArtServicesPage() {
  return (
    <main>
      <GameArtServices />
    </main>
  );
}