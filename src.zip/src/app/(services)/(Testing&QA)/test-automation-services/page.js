import TestAutomation from '@/pages/TestAutomation';

export default function TestAutomationPage() {
  return (
    <main>
      <TestAutomation />
    </main>
  );
}
